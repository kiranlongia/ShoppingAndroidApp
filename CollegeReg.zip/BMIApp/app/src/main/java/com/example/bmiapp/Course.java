package com.example.bmiapp;

public class Course {
    private String course;
    private int fees;
    private int hours;

    public Course(String course, int fees, int hours) {
        this.course = course;
        this.fees = fees;
        this.hours = hours;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public int getFees() {
        return fees;
    }

    public void setFees(int fees) {
        this.fees = fees;
    }

    public int getHours() {
        return hours;
    }

    public void setHours(int hours) {
        this.hours = hours;
    }
}
