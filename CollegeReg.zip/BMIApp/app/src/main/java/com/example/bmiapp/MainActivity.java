package com.example.bmiapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemSelectedListener {
    //declare variable for the design items
    TextView fees,hours;
    ArrayList<Course> courselist = new ArrayList<Course>();
    String courses[] = {"Java","Swift","ios","Android","Database"};
    Spinner sp;
    TextView  welcome;
    ArrayList <Course> selectedcourse = new ArrayList<Course>();

    public  void fillCourseData()
    {
        courselist.add(new Course("Java",1300,6));
        courselist.add(new Course("Swift",1500,5));
        courselist.add(new Course("ios",1350,5));
        courselist.add(new Course("Android",1400,7));
        courselist.add(new Course("Database",1100,4));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        welcome = findViewById(R.id.tvWelcome);
        welcome.setText("Welcome "+ LogInActivity.name.getText()); //use a variable from another activity
        //set buttons as listeners


    }
    //in this method where we write the code of the actions
    @Override
    public void onClick(View view) {





    }



    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}
