package com.example.bmiapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemSelectedListener {

    TextView fees,hours,totalfee,totalhrs;
    Button addbtn,regbtn;
    ArrayList<Course> courselist = new ArrayList<Course>();
    String courses[] = {"Java","Swift","ios","Android","Database"};
    Spinner sp;
    TextView  welcome;
    ArrayList <Course> selectedcourse = new ArrayList<Course>();

    public  void fillCourseData()
    {
        courselist.add(new Course("Java",1300,6));
        courselist.add(new Course("Swift",1500,5));
        courselist.add(new Course("ios",1350,5));
        courselist.add(new Course("Android",1400,7));
        courselist.add(new Course("Database",1100,4));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fillCourseData();
        sp=findViewById(R.id.spCourse);
        fees=findViewById(R.id.txtfees);
        hours=findViewById(R.id.txthours);
        totalfee=findViewById(R.id.tvfees);
        totalhrs=findViewById(R.id.tvhours);
        addbtn=findViewById(R.id.btnAdd);
        regbtn=findViewById(R.id.btnReg);

        addbtn.setOnClickListener(this);
        regbtn.setOnClickListener(this);

        welcome = findViewById(R.id.tvWelcome);
        welcome.setText("Welcome!! "+ LogInActivity.studentName.getText()); //use a variable from another activity

        ArrayAdapter aa=new ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,courses);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp.setAdapter(aa);//fill the spinner from the adapter

sp.setOnItemSelectedListener(this);
    }
    //in this method where we write the code of the actions
    @Override
    public void onClick(View view) {



    }
    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
      //  if(adapterView.getId()==R.id.spCourse)
           // String r1 = String.format("%.2f",courses);
        }
        public int searchCourse(String Coursetype){
        for(int i=0;i<courselist.size();i++)
            if(courselist.get(i).getCourse().equals(Coursetype))
                return  i;
            return -1;




    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}
