package com.example.laptopapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class CarDetailsActivity extends AppCompatActivity {
TextView laptopBrand;
EditText model,priceET;
ImageView lapImg;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_car_details);
        laptopBrand=findViewById(R.id.tvTitle);
        model=findViewById(R.id.etModel);
        lapImg=findViewById(R.id.imageView2);
        priceET=findViewById(R.id.etPrice);

        laptopBrand.setText(MainActivity.selectedLaptopBrand);
        model.setText(MainActivity.selectedLaptopModel);
        priceET.setText(String.format("%.2f",MainActivity.selectedLaptopPrice));
        lapImg.setImageResource(MainActivity.img);
    }
}
