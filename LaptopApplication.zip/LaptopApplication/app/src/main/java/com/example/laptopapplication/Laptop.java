package com.example.laptopapplication;

public class Laptop {
    private String brand;
    private String model;
    private double price;
    private int img;

    public Laptop(String brand, String model, double price, int img) {
        this.brand = brand;
        this.model = model;
        this.price = price;
        this.img = img;
    }

    public String getBrand() {
        return brand;
    }

    public String getModel() {
        return model;
    }

    public double getPrice() {
        return price;
    }

    public int getImg() {
        return img;
    }
}
