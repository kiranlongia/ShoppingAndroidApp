package com.example.laptopapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class ListAdapter extends BaseAdapter {
private ArrayList<Laptop> laptopData;
private LayoutInflater layoutInflater;

    public ListAdapter(Context context, ArrayList<Laptop> laptopData) {
        this.laptopData = laptopData;
        layoutInflater= LayoutInflater.from(context);

    }

    @Override
    public int getCount() {
        return laptopData.size();
    }

    @Override
    public Object getItem(int position) {
        return laptopData.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if( convertView==null){

           convertView= layoutInflater.inflate(R.layout.list_row,null);
            holder=new ViewHolder();
            holder.modelTv=convertView.findViewById(R.id.tvModel);
            holder.priceTv=convertView.findViewById(R.id.tvPrice);
            holder.img=convertView.findViewById(R.id.imageView);
            convertView.setTag(holder);
        }
        else

        holder=(ViewHolder) convertView.getTag();
        holder.modelTv.setText(laptopData.get(position).getModel());
        holder.priceTv.setText(String.format("%.2f",laptopData.get(position).getPrice()));
        holder.img.setImageResource(laptopData.get(position).getImg());

        return convertView;
    }
    static class ViewHolder{
        private TextView modelTv;
        private  TextView priceTv;
        private ImageView img;
    }
}
