package com.example.laptopapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener, AdapterView.OnItemClickListener {
ListView lv;
ArrayList<Laptop> laptopList=new ArrayList<Laptop>();
String brands[]={"Acer","Dell","Ascus","Sony"};
Spinner brandSp;
ArrayList <Laptop> selectedLaps=new ArrayList<Laptop>();//arraylist for spinner formation
public static String selectedLaptopBrand;
public static String selectedLaptopModel;
public static double selectedLaptopPrice;
public static int img;

//filling the laptops data
    public void fillLaptopsData(){
        laptopList.add(new Laptop("Acer","Aspire 5",1200,R.drawable.acer21));
        laptopList.add(new Laptop("Dell","Inspiron 15",1340,R.drawable.dellinspiron));
        laptopList.add(new Laptop("Dell","Latitude 15",2345,R.drawable.dellg5));
        laptopList.add(new Laptop("Ascus","Notebook 14",1500,R.drawable.ascuszenbook));
        laptopList.add(new Laptop("Ascus","Spin 15",1380,R.drawable.asus156));
        laptopList.add(new Laptop("Sony","VAIOS X",1800,R.drawable.sonyvaiosx14));
        laptopList.add(new Laptop("Acer","Swift",2000,R.drawable.acerswift));
        laptopList.add(new Laptop("Dell","XPS",1499,R.drawable.dellxps));
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fillLaptopsData();

        lv=findViewById(R.id.lvLaptops);

        //initilize the spinner
        brandSp=findViewById(R.id.spBrands);
        //create the adapter for the spinner
        ArrayAdapter aa=new ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,brands);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        brandSp.setAdapter(aa);//fill the spinner from the adapter

        brandSp.setOnItemSelectedListener(this);
        lv.setOnItemSelectedListener(this);
        lv.setOnItemClickListener(this);
    }
    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        if(adapterView.getId()==R.id.spBrands) {
            selectedLaps.clear();//selectedlaps is array list of laptops which belong to  the selected laptops make form the spinner
            String brand = brands[i];//brands is an array of brands(acer,dell,axus,sony)
            for (int j = 0; j < laptopList.size(); j++)//another arraylist "laptoplist" of all laptop details
                if (laptopList.get(j).getBrand().equals(brand))
                    selectedLaps.add(laptopList.get(j));
            lv.setAdapter(new ListAdapter(this, selectedLaps));
        }
      }
@Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        if(adapterView.getId()==R.id.lvLaptops){
            selectedLaptopBrand=selectedLaps.get(i).getBrand();
            selectedLaptopModel=selectedLaps.get(i).getModel();
            selectedLaptopPrice=selectedLaps.get(i).getPrice();
            img=selectedLaps.get(i).getImg();
            Intent intent = new Intent(this,CarDetailsActivity.class);
            startActivity(intent);
        }
    }


    }
