package com.example.rentalapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.Spinner;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    String carMake[] = {"Nissan","Ford","Toyota"};
    ArrayList<Car> cars = new ArrayList<Car>();
    ArrayList<String>selectdMake = new ArrayList<String>();
    Spinner makeSp,typeSp;
    CheckBox navCh, camCb,roofCb,keyCb;

    //method to fill the car details in the list
    public void setCarsDetails(){

        int[] options = {0,1,1,0};
        cars.add(new Car("ABC 234","Ford","Escape",40,0.7,3450,options));
        int []options2 = {1,0,1,0};
        cars.add(new Car("XYR 837","Nissan","Rogue",45,0.75,2560,options2));
        int[] options3 = {1,0,0,0};
        cars.add(new Car("ABC 234","Ford","Edge",50,0.7,1234,options3));
        int[] options4 = {0,1,1,0};
        cars.add(new Car("RLB 456","Nissan","Sunny",30,0.5,3450,options4));
        int[] options5 = {0,0,1,0};
        cars.add(new Car("ASD 634","Toyota","Corolla",37,0.6,5678,options5));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setCarsDetails();
        makeSp=findViewById(R.id.SpMake);
        typeSp=findViewById(R.id.spType);
        navCh=findViewById(R.id.cb1);
        camCb=findViewById(R.id.cb2);
        roofCb=findViewById(R.id.cb3);
        keyCb=findViewById(R.id.cb4);

        makeSp.setOnItemSelectedListener(this);
        typeSp.setOnItemSelectedListener(this);

        ArrayAdapter makeAdap = new ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,carMake);
        makeAdap.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        makeSp.setAdapter(makeAdap);
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        if(adapterView.getId()==R.id.SpMake){
            selectdMake.clear();
            for(int j=0;j<cars.size();j++){
                if(cars.get(j).getMake().equals(carMake[i]))
                    selectdMake.add(cars.get(j).getType());
            }
            ArrayAdapter aa = new ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,selectdMake);
            aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            typeSp.setAdapter(aa);


        }
        else if(adapterView.getId()==R.id.spType){
            int intdex=searchCars(selectdMake.get(i));
            chkBoxes(selectdMake.get(i));




        }
    }

    public void chkBoxes(String carType){
        int i = searchCars(carType);
        if(cars.get(i).getOptions()[0]==1)
            navCh.setChecked(true);
        else
            navCh.setChecked(false);
        if(cars.get(i).getOptions()[1]==1)
            camCb.setChecked(true);
        else
            camCb.setChecked(false);
        if(cars.get(i).getOptions()[2]==1)
            roofCb.setChecked(true);
        else
            roofCb.setChecked(false);
        if(cars.get(i).getOptions()[3]==1)
            keyCb.setChecked(true);
        else
            keyCb.setChecked(false);


    }
    public int searchCars(String carType){
        for(int i=0;i<cars.size();i++)
            if(cars.get(i).getType().equals(carType))
                return i;
        return -1;
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}
